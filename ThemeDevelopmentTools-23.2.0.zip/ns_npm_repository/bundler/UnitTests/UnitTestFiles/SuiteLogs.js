define('SuiteLogs', [], function() {});
