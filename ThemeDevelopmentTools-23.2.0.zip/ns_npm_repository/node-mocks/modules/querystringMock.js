module.exports = {
    mock() {
        return { parse: jest.fn() };
    }
};
