TODO / WIP 

## system requirements

 * install nodejs
 * sudo npm install -g gulp

## Install devtools

 * download devtools.zip from SuiteCommerce extension bundle
 * unzip-it
 * npm install


## TODO

 * fetch
 * deploy
 * local