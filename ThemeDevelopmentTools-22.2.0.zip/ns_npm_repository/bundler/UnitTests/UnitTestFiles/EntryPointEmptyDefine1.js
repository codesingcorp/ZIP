define('EntryPointEmptyDefine1', ['EmptyDefineWithArray'], function() {});
