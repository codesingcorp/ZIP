define('EntryPointDuplicatedDependencies', [
    'Dependency1',
    'Dependency2',
    'Dependency2',
    'Dependency1'
], function() {});
