define('EntryPointRequireAndExports1', ['require', 'exports', 'Dependency3'], function() {});
