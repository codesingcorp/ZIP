define('Dependency1', ['Dependency2'], function() {});
