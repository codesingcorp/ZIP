define('EntryPointCycling1', ['DependencyCycling1'], function() {});
