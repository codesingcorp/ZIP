module.exports = {
    mock() {
        return { homedir: jest.fn() };
    }
};
