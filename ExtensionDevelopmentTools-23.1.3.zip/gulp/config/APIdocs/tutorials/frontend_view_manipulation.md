# WIP / TODO

how to manipulate existing views and add new ones: 

 * See {@tutorial frontend_defining_new_views} to learn how to implement new Views. 

 * componenets inherithing from VisualComponent allow users to manipulate these components views in a controlled manner. 

 * LayoutComponent allow to manipulate any view

 * child views and `data-view` HTML attribute relationship

 * explain how to use addChildView, removeChildView, add/remove toViewContextDefinition, add/remove toViewEventsDefinition, etc

 * data-view HTML attribute and and compatibility